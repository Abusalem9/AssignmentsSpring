package com.masai;

public class NoDataFoundException extends RuntimeException {
    NoDataFoundException(){}
    NoDataFoundException(String message){
        super(message);
    }
}
