package com.masai;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;

@Data
@Entity
public class Book {
    @Id
    private Integer Book_Id;
    private String name;
    private String author;
    private Integer price;
}
