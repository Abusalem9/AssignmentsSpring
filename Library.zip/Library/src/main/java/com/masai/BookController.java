package com.masai;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
public class BookController implements BookService{
    @Autowired
    public  BookRepository bookRepository;
    @Override
    @PostMapping("/Book/save")
    public Book SaveBook(@RequestBody Book book) {
        return bookRepository.save(book);
    }
    @PostMapping("/Book/Update")
    @Override
    public Book updateBook(@RequestBody Book book) {
           Optional<Book> book1=bookRepository.findById(book.getBook_Id());
           if(book1.isPresent()){
               book1.get();
               return bookRepository.save(book);
           }
           else
               throw new BookNotFoundException("Book Not Found");
    }
    @DeleteMapping("/Book/Delete/{id}")
    @Override
    public String deleteBook(@PathVariable("id") Integer id) {
        Optional<Book> book1=bookRepository.findById(id);
        if(book1.isPresent()){
            Book book=book1.get();
            bookRepository.delete(book);
            return "Book Has Been Deleted Successfully.";
        }
        else
            throw new BookNotFoundException("Book Not Found");
    }
    @GetMapping("/Books")
    @Override
    public List<Book> getAllBooks() {
        List<Book> book = bookRepository.findAll();
        if(book.size()>=1){
            return book;
        }
        else
            throw new NoDataFoundException("No Data Found");
    }
    @GetMapping("/Book/{id}")
    @Override
    public Book getBookById(@PathVariable("id") Integer id) {
        Optional<Book> book1=bookRepository.findById(id);
        if(book1.isPresent()){
            return book1.get();
        }
        else
            throw new BookNotFoundException("Book Not Found");
    }
}
