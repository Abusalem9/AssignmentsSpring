package com.masai;

public class BookNotFoundException extends RuntimeException {
    BookNotFoundException(){

    }
    BookNotFoundException(String message){
        super(message);
    }
}
