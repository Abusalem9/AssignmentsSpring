package com.masai;

import java.util.List;

public interface BookService {
    Book SaveBook(Book book);
    Book updateBook(Book book);
    String deleteBook(Integer id);

    List<Book> getAllBooks();

    Book getBookById(Integer id);
}
